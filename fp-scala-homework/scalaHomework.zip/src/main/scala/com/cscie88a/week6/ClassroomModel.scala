package com.cscie88a.week6

// add Student, Subject, and Score case classes and companion objects below